import express from 'express';
import { asyncHandler } from '../../../middleware/async.js';
import { logger } from '../../../utils/logger/index.js';

const logsRoutes = () => {
    const router = express.Router();
    
    // Get all logs
    router.get('/', asyncHandler(async (req, res) => {
        try {
            const logs = await logger.getLogs();
            res.json({ success: true, data: logs });
        } catch (error) {
            console.error('Error retrieving logs:', error);
            res.status(500).json({ success: false, error: 'Failed to retrieve logs' });
        }
    }));

    // Get logs by level
    router.get('/level/:level', asyncHandler(async (req, res) => {
        try {
            const { level } = req.params;
            const logs = await logger.getLogsByLevel(level);
            res.json({ success: true, data: logs });
        } catch (error) {
            console.error(`Error retrieving logs by level ${req.params.level}:`, error);
            res.status(500).json({ success: false, error: 'Failed to retrieve logs by level' });
        }
    }));

    // Get logs by component
    router.get('/component/:component', asyncHandler(async (req, res) => {
        try {
            const { component } = req.params;
            const logs = await logger.getLogsByComponent(component);
            res.json({ success: true, data: logs });
        } catch (error) {
            console.error(`Error retrieving logs by component ${req.params.component}:`, error);
            res.status(500).json({ success: false, error: 'Failed to retrieve logs by component' });
        }
    }));

    return router;
};

export default logsRoutes;
