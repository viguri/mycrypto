#!/bin/bash
set -e

echo "Updating MyCrypto application..."

# Stop running containers
echo "Stopping running containers..."
docker-compose down || true

# Update application files
echo "Updating application files..."

# Ensure the symbolic link is correct
if [ -L "httpdocs" ]; then
  echo "Ensuring symbolic link is correct..."
  rm -f httpdocs
  ln -sf client/public httpdocs
else
  echo "Creating symbolic link..."
  mv httpdocs httpdocs.bak 2>/dev/null || true
  ln -sf client/public httpdocs
fi

# Update .htaccess file
echo "Updating .htaccess file..."
cat > client/public/.htaccess << 'HTACCESS'
# Enable rewrite engine
RewriteEngine On

# API Proxy Rules
RewriteCond %{REQUEST_URI} ^/api/(.*)
RewriteRule ^api/(.*) http://172.17.0.1:3003/api/$1 [P,L]

# Handle OPTIONS requests for CORS preflight
RewriteCond %{REQUEST_METHOD} OPTIONS
RewriteRule ^(.*)$ $1 [R=200,L]

# SPA Rewrite Rules - Only if not an existing file or directory
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^ index.html [L]

# CORS headers
<IfModule mod_headers.c>
    Header always set Access-Control-Allow-Origin "*"
    Header always set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
    Header always set Access-Control-Allow-Headers "Origin, X-Requested-With, Content-Type, Accept, Authorization"
</IfModule>
HTACCESS

# Update client-side JavaScript to use relative URLs
echo "Updating client-side JavaScript to use relative URLs..."
find client/public -type f -name "*.js" -exec grep -l "localhost:3003/api" {} \; | while read file; do
    echo "Updating $file..."
    sed -i 's|http://localhost:3003/api|/api|g' "$file"
    sed -i 's|http://127.0.0.1:3003/api|/api|g' "$file"
done

# Start containers
echo "Starting containers..."
docker-compose up -d

# Wait for containers to start
echo "Waiting for containers to start..."
sleep 10

# Test API endpoint
echo "Testing API endpoint..."
curl -s http://localhost:3003/api/test && echo " <- Node.js server is working!" || echo "Failed to connect to Node.js server"

echo "Update completed successfully!"
